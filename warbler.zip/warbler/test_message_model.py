"""Message Model Tests"""
import os
from unittest import TestCase
from sqlalchemy import exc
from models import db, Message, Follows,User, Likes

# Lets set up a mock database before we run our tests

os.environ['DATABASE_URL'] = "postgresql:///warbler-test2"

from app import app
db.create_all()

class UserModelTestCase(TestCase):
    """Tests for the messages"""
    def setUp(self):
        """create test client and add in sample data"""
        db.drop_all()
        db.create_all()

        self.client = app.test_client()
        self.userid= 25
        user = User.signup(username='message',password='password', email="mock@yahoo.com", image_url= None)
        user.id = self.userid
        db.session.commit()
        
        self.user= User.query.get_or_404(self.userid)

        def tearDown(self):
            dt = super().tearDown()
            db.session.rollback()
            return dt
        
        def test_message(self):
            """Confirm if the message model is working properly"""
            msg = Message( text = "Hello World", user_id= self.userid)
            db.session.add(msg)
            db.session.commit()

            # The user in questions should now have one new message
            self.assertEqual(len(self.user.messages),1)
        
        def test_message_likes(self):
            msg = Message( text = "Hello World", user_id= self.userid)
            msg2 = Message( text = "Hello World!!!", user_id= self.userid)

            newUser= User.signup(username='messagejnew',password='2password', email="mock2@yahoo.com", image_url= None)
            newUserid = 45
            newUser.id = newuser2
            db.session.add_all([msg,msg2,newUser])
            db.session.commit()
            newUser.likes.append(msg)
            db.session.commit()

            like= Likes.query.filter(Likes.user_id == newuser2).all()
            self.assertEqual(len(like),1)
